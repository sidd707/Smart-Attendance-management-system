# User Credentials
host = 'localhost'
user = 'root'
password = '210105'
database = 'student'